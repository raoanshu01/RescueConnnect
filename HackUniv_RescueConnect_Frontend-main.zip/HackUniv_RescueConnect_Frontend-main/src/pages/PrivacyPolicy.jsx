import React from 'react'

const PrivacyPolicy = () => {
  return (
    <div>
      This is privacy policy page
    </div>
  )
}

export default PrivacyPolicy
