# sih-backend


use npm install command to install all the dependencies.
simply run the server using the npm run dev command
use Mongo DB Compass to run the application by pasting the url which is in the config file
